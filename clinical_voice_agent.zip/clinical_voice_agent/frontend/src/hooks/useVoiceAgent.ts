import { useState, useEffect, useRef } from 'react';

export function useVoiceAgent(phoneNumber: string) {
  const [isConnected, setIsConnected] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState<string[]>([]);
  
  const wsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Buffer to queue incoming audio chunks for smooth playback
  const audioQueueRef = useRef<ArrayBuffer[]>([]);
  const isPlayingRef = useRef(false);

  useEffect(() => {
    // Connect WebSocket
    const ws = new WebSocket(`ws://localhost:8000/ws/${phoneNumber}`);
    
    ws.onopen = () => {
      setIsConnected(true);
      console.log('Connected to Voice Agent');
    };
    
    ws.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        if (event.data === "END_OF_AUDIO") {
          // Playback finished signal
        } else {
          setTranscript(prev => [...prev, `Agent: ${event.data}`]);
        }
      } else if (event.data instanceof Blob) {
        // We received raw audio bytes, likely PCM or specific format
        // In this implementation we assume standard arraybuffer playback
        const arrayBuffer = await event.data.arrayBuffer();
        audioQueueRef.current.push(arrayBuffer);
        playNextInQueue();
      }
    };
    
    ws.onclose = () => {
      setIsConnected(false);
      console.log('Disconnected');
    };
    
    wsRef.current = ws;
    
    return () => {
      ws.close();
    };
  }, [phoneNumber]);

  const playNextInQueue = async () => {
    if (isPlayingRef.current || audioQueueRef.current.length === 0) return;
    
    isPlayingRef.current = true;
    if (!audioContextRef.current) {
      audioContextRef.current = new window.AudioContext();
    }
    
    const arrayBuffer = audioQueueRef.current.shift();
    if (arrayBuffer) {
        try {
            // Note: In a real system, the TTS format must match the decode format.
            // OpenAI returns raw mp3 or pcm. DecodeAudioData handles standard formats.
            const audioBuffer = await audioContextRef.current.decodeAudioData(arrayBuffer);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            source.onended = () => {
              isPlayingRef.current = false;
              playNextInQueue();
            };
            source.start(0);
        } catch (e) {
            console.error("Error decoding audio", e);
            isPlayingRef.current = false;
            playNextInQueue();
        }
    }
  };

  const startRecording = async () => {
    if (!navigator.mediaDevices) {
      alert("Media devices not supported on this browser.");
      return;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    
    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        audioChunksRef.current.push(event.data);
      }
    };
    
    mediaRecorder.onstop = async () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
      audioChunksRef.current = []; // reset
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        // Send to backend
        wsRef.current.send(audioBlob);
        setTranscript(prev => [...prev, "You: (Audio sent)"]);
      }
      stream.getTracks().forEach(track => track.stop());
    };
    
    mediaRecorderRef.current = mediaRecorder;
    mediaRecorder.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return {
    isConnected,
    isRecording,
    startRecording,
    stopRecording,
    transcript
  };
}
