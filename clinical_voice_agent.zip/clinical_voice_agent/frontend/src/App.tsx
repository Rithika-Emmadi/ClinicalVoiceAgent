import React, { useState } from 'react';
import { useVoiceAgent } from './hooks/useVoiceAgent';
import './index.css';

function App() {
  const [phoneNumber, setPhoneNumber] = useState('1234567890');
  const [isSessionActive, setIsSessionActive] = useState(false);
  
  // The hook initializes connection when the component mounts if we wrap it,
  // but we want to control when it connects. We'll render a sub-component.
  return (
    <div className="app-container">
      <div className="header">
        <h1>HealthVoice AI</h1>
        <p>Real-time Multilingual Clinical Agent</p>
      </div>

      {!isSessionActive ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '2rem' }}>
          <input 
            type="text" 
            value={phoneNumber} 
            onChange={(e) => setPhoneNumber(e.target.value)} 
            placeholder="Enter Phone Number"
            style={{
              padding: '1rem',
              borderRadius: '12px',
              border: '1px solid var(--surface-border)',
              background: 'rgba(0,0,0,0.2)',
              color: 'white',
              fontSize: '1rem',
              textAlign: 'center',
              outline: 'none'
            }}
          />
          <button 
            className="mic-button" 
            style={{ width: '100%', height: '50px', borderRadius: '12px' }}
            onClick={() => setIsSessionActive(true)}
          >
            Start Session
          </button>
        </div>
      ) : (
        <ActiveSession phoneNumber={phoneNumber} />
      )}
    </div>
  );
}

function ActiveSession({ phoneNumber }: { phoneNumber: string }) {
  const { isConnected, isRecording, startRecording, stopRecording, transcript } = useVoiceAgent(phoneNumber);

  return (
    <>
      <div className="status-indicator">
        <div className={`dot ${isConnected ? 'connected' : 'disconnected'}`}></div>
        {isConnected ? 'Agent Connected' : 'Connecting...'}
      </div>

      <div style={{ margin: '2rem 0' }}>
        <button 
          className={`mic-button ${isRecording ? 'recording' : ''}`}
          onMouseDown={startRecording}
          onMouseUp={stopRecording}
          onTouchStart={startRecording}
          onTouchEnd={stopRecording}
        >
          {isRecording ? 'Listening...' : 'Hold to Speak'}
        </button>
      </div>

      <div className="transcript-container">
        {transcript.length === 0 ? (
          <p style={{ textAlign: 'center', marginTop: '4rem', opacity: 0.5 }}>
            Hold the button and speak to interact with the agent.
          </p>
        ) : (
          transcript.map((line, i) => (
            <p key={i}>{line}</p>
          ))
        )}
      </div>
    </>
  );
}

export default App;
