import asyncio
import json
from fastapi import WebSocket
from sqlalchemy.orm import Session
from services.stt import STTService
from services.llm import LLMService
from services.tts import TTSService
from tools import get_appointment_tools, execute_tool

class Orchestrator:
    def __init__(self, db: Session, patient_context: dict):
        self.db = db
        self.patient_context = patient_context
        self.stt = STTService()
        self.llm = LLMService()
        self.tts = TTSService()
        self.messages = []
        self.tools = get_appointment_tools()

    async def handle_connection(self, websocket: WebSocket):
        await websocket.accept()
        print(f"[Orchestrator] Connection established for patient {self.patient_context.get('id')}")

        # Send an initial greeting if needed, or wait for user to speak
        await self.speak_and_send("Hello, I am the clinic's AI assistant. How can I help you today?", websocket)

        try:
            while True:
                # Receive audio chunk from frontend (assuming client-side VAD chunks it)
                message = await websocket.receive_bytes()
                
                if not message:
                    continue

                # 1. STT
                print("[Orchestrator] Received audio, starting STT...")
                user_text = await self.stt.transcribe(message, self.patient_context.get("preferred_language", "English"))
                print(f"[Orchestrator] User said: {user_text}")
                
                if not user_text.strip():
                    continue

                self.messages.append({"role": "user", "content": user_text})

                # 2. LLM
                print("[Orchestrator] Starting LLM...")
                llm_response_gen = self.llm.generate_response(self.messages, self.patient_context, self.tools)
                
                # To achieve low latency, we collect sentences and send them to TTS immediately
                # For simplicity in this demo, we'll collect the full response or handle tool calls
                full_response = ""
                tool_calls_data = None
                
                async for chunk in llm_response_gen:
                    if chunk.startswith('{"__tool_calls__"'):
                        tool_calls_data = json.loads(chunk)
                        break
                    full_response += chunk
                    # Here we could implement sentence-boundary detection for streaming TTS
                
                if tool_calls_data:
                    self.messages.append({"role": "assistant", "content": None, "tool_calls": tool_calls_data["__tool_calls__"]})
                    
                    for tc in tool_calls_data["__tool_calls__"]:
                        result = execute_tool(tc, self.db, self.patient_context['id'])
                        self.messages.append({
                            "role": "tool",
                            "tool_call_id": tc["id"],
                            "name": tc["function"]["name"],
                            "content": result
                        })
                    
                    # Get second response after tool execution
                    print("[Orchestrator] Tool executed, getting final response...")
                    llm_response_gen = self.llm.generate_response(self.messages, self.patient_context, self.tools)
                    full_response = ""
                    async for chunk in llm_response_gen:
                         full_response += chunk
                
                self.messages.append({"role": "assistant", "content": full_response})
                print(f"[Orchestrator] Assistant response: {full_response}")
                
                # 3. TTS
                await self.speak_and_send(full_response, websocket)

        except Exception as e:
            print(f"[Orchestrator] Connection closed or error: {e}")

    async def speak_and_send(self, text: str, websocket: WebSocket):
        print(f"[Orchestrator] Streaming TTS for: {text}")
        audio_stream = self.tts.stream_audio(text)
        async for audio_chunk in audio_stream:
            await websocket.send_bytes(audio_chunk)
        # Send a control message to indicate end of audio playback
        await websocket.send_text("END_OF_AUDIO")
