from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from database import engine, get_db, init_db
from models import Patient
from orchestrator import Orchestrator

app = FastAPI(title="Clinical Voice Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()

@app.websocket("/ws/{phone_number}")
async def websocket_endpoint(websocket: WebSocket, phone_number: str, db: Session = Depends(get_db)):
    # 1. Retrieve or create patient profile
    patient = db.query(Patient).filter(Patient.phone_number == phone_number).first()
    if not patient:
        patient = Patient(phone_number=phone_number, name="Guest", preferred_language="English")
        db.add(patient)
        db.commit()
        db.refresh(patient)

    # 2. Extract context
    patient_context = {
        "id": patient.id,
        "name": patient.name,
        "preferred_language": patient.preferred_language,
        "context_summary": patient.context_summary,
    }

    # 3. Instantiate orchestrator for this session
    orchestrator = Orchestrator(db, patient_context)

    # 4. Handle connection
    await orchestrator.handle_connection(websocket)
