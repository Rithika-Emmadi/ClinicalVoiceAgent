from datetime import datetime
from sqlalchemy.orm import Session
from models import Appointment, Patient

def get_appointment_tools():
    """Returns the OpenAI function definitions for available tools."""
    return [
        {
            "type": "function",
            "function": {
                "name": "check_availability",
                "description": "Check if a specific doctor is available on a given date.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "doctor_name": {"type": "string", "description": "The name of the doctor."},
                        "date": {"type": "string", "description": "The date to check, in YYYY-MM-DD format."}
                    },
                    "required": ["doctor_name", "date"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "book_appointment",
                "description": "Book an appointment for the patient.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "doctor_name": {"type": "string", "description": "The name of the doctor."},
                        "datetime": {"type": "string", "description": "The date and time to book, in YYYY-MM-DD HH:MM:SS format."}
                    },
                    "required": ["doctor_name", "datetime"]
                }
            }
        }
    ]

def execute_tool(tool_call: dict, db: Session, patient_id: int) -> str:
    """Executes a tool call and returns the result as a string."""
    import json
    name = tool_call["function"]["name"]
    try:
        args = json.loads(tool_call["function"]["arguments"])
    except json.JSONDecodeError:
        return "Error: Invalid arguments provided."

    if name == "check_availability":
        # Mock logic: assume doctors are available between 9 AM and 5 PM
        return f"{args['doctor_name']} has slots available at 10:00 AM and 2:00 PM on {args['date']}."
        
    elif name == "book_appointment":
        try:
            appt_time = datetime.strptime(args['datetime'], "%Y-%m-%d %H:%M:%S")
            # Check for conflict
            conflict = db.query(Appointment).filter(
                Appointment.doctor_name == args['doctor_name'],
                Appointment.appointment_time == appt_time,
                Appointment.status == "scheduled"
            ).first()
            
            if conflict:
                return f"Error: Slot {args['datetime']} is already booked."
                
            new_appt = Appointment(
                patient_id=patient_id,
                doctor_name=args['doctor_name'],
                appointment_time=appt_time
            )
            db.add(new_appt)
            db.commit()
            return "Appointment successfully booked."
            
        except ValueError:
            return "Error: Invalid datetime format. Use YYYY-MM-DD HH:MM:SS."
            
    return "Error: Tool not recognized."
