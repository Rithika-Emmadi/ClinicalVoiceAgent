import os
import openai
import asyncio
from typing import AsyncGenerator

class TTSService:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        if self.api_key:
            self.client = openai.AsyncOpenAI(api_key=self.api_key)
        else:
            self.client = None

    async def stream_audio(self, text: str) -> AsyncGenerator[bytes, None]:
        """
        Converts text to speech and streams back audio chunks.
        In a production system <450ms, this connects via WebSocket to ElevenLabs or Cartesia.
        Here we use OpenAI TTS streaming.
        """
        if not self.client:
            print(f"[TTS] Mock generating audio for: {text}")
            await asyncio.sleep(0.2)
            yield b"MOCK_AUDIO_DATA_CHUNK_1"
            await asyncio.sleep(0.1)
            yield b"MOCK_AUDIO_DATA_CHUNK_2"
            return

        try:
            response = await self.client.audio.speech.create(
                model="tts-1",
                voice="alloy",
                input=text,
                response_format="pcm" # WebSockets usually handle raw PCM or specific Opus
            )
            # We stream the raw bytes in chunks
            for chunk in response.iter_bytes(chunk_size=4096):
                yield chunk
        except Exception as e:
            print(f"[TTS Error]: {e}")
