import os
import openai
import tempfile
import asyncio

class STTService:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        if self.api_key:
            self.client = openai.AsyncOpenAI(api_key=self.api_key)
        else:
            self.client = None

    async def transcribe(self, audio_bytes: bytes, language: str = "en") -> str:
        """
        Transcribes audio bytes to text.
        In a production low-latency system, this would stream chunks to Deepgram.
        Here we use OpenAI Whisper for a functional demo.
        """
        if not self.client:
            print("[STT] No API key, returning mock transcription")
            await asyncio.sleep(0.5)
            return "I need to book an appointment with Dr. Smith for tomorrow."

        # Write bytes to a temporary file because OpenAI API expects a file-like object with a name
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name

        try:
            with open(tmp_path, "rb") as audio_file:
                # Map standard language names to ISO-639-1 if needed, Whisper auto-detects well
                response = await self.client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    language="en" if language == "English" else ("hi" if language == "Hindi" else "ta")
                )
            return response.text
        except Exception as e:
            print(f"[STT Error]: {e}")
            return ""
        finally:
            os.remove(tmp_path)
