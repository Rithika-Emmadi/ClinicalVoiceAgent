import os
import openai
from typing import List, Dict, Any, AsyncGenerator
import json

class LLMService:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        if self.api_key:
            self.client = openai.AsyncOpenAI(api_key=self.api_key)
        else:
            self.client = None

    def _get_system_prompt(self, patient_name: str, preferred_language: str, context: str) -> str:
        return f"""You are a helpful, professional AI assistant for a digital healthcare platform.
Your goal is to help patients book, cancel, or reschedule clinical appointments.
The patient's name is {patient_name or 'Unknown'}.
The patient's preferred language is {preferred_language}. You MUST reply in this language.
Patient History/Context: {context}

You have access to tools to check availability and manage appointments.
If a patient asks for a specific time, use the check_availability tool first.
Keep your responses very concise and conversational. Do not output long lists or markdown formatting, as your response will be spoken out loud via text-to-speech.
"""

    async def generate_response(self, messages: List[Dict[str, str]], patient_context: Dict[str, Any], available_tools: List[Dict] = None) -> AsyncGenerator[str, None]:
        """
        Generates a conversational response streaming back chunks of text.
        """
        system_prompt = self._get_system_prompt(
            patient_context.get('name', ''),
            patient_context.get('preferred_language', 'English'),
            patient_context.get('context_summary', '')
        )
        
        full_messages = [{"role": "system", "content": system_prompt}] + messages

        if not self.client:
            print("[LLM] Mock generating text")
            yield "This is a mock response because no API key is provided. "
            yield "Please provide an API key to enable real functionality."
            return

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=full_messages,
                tools=available_tools,
                stream=True
            )
            
            tool_calls_buffer = []
            
            async for chunk in response:
                delta = chunk.choices[0].delta
                
                if delta.content:
                    yield delta.content
                    
                # We also need to handle tool calls in streaming mode, which is complex.
                # For this assignment's robust demo, if a tool call is detected, we accumulate it.
                if delta.tool_calls:
                    for tc in delta.tool_calls:
                        if len(tool_calls_buffer) <= tc.index:
                            tool_calls_buffer.append({"id": tc.id, "function": {"name": tc.function.name, "arguments": ""}})
                        if tc.function.arguments:
                            tool_calls_buffer[tc.index]["function"]["arguments"] += tc.function.arguments

            if tool_calls_buffer:
                # Emit a special control message indicating tools need to be executed
                yield json.dumps({"__tool_calls__": tool_calls_buffer})

        except Exception as e:
            print(f"[LLM Error]: {e}")
            yield "I'm sorry, I encountered an error while processing your request."
