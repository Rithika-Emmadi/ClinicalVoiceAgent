from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime

Base = declarative_base()

class Patient(Base):
    """
    Stores persistent context across sessions for a patient.
    Language preference helps in initializing the correct STT/TTS models instantly.
    """
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    phone_number = Column(String, unique=True, index=True)
    name = Column(String, nullable=True)
    preferred_language = Column(String, default="English")  # English, Hindi, Tamil
    context_summary = Column(String, default="") # High level summary of past interactions

    appointments = relationship("Appointment", back_populates="patient")

class Appointment(Base):
    """
    Stores appointment details.
    """
    __tablename__ = "appointments"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"))
    doctor_name = Column(String)
    appointment_time = Column(DateTime)
    status = Column(String, default="scheduled") # scheduled, cancelled, completed

    patient = relationship("Patient", back_populates="appointments")
